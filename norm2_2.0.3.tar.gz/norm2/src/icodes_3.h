"A zero-length string is invalid                                         ",&
"Argument beta has incorect length                                       ",&
"Argument criterion cannot be negative                                   ",&
"Argument impute_every cannot be negative                                ",&
"Argument impute_every cannot exceed max_iter                            ",&
"Argument iwkp has incorect length                                       ",&
"Argument max_iter cannot be negative                                    ",&
"Argument max_iter must be positive                                      ",&
"Argument multicycle must be positive                                    ",&
"Argument omit has incorect length                                       ",&
"Argument piv has incorrect length                                       ",&
"Argument prior_sscp has incorrect dimensions                            ",&
"Argument r has incorect dimensions                                      ",&
"Argument wkn has incorect length                                        ",&
"Argument wkn1 or wkn2 has incorect length                               ",&
"Argument wknp has incorect dimensions                                   ",&
"Argument wkp has incorect length                                        ",&
"Argument wkp1 or wkp2 has incorect length                               ",&
"Argument wkpp has incorect dimensions                                   ",&
"Argument x has more columns than rows                                   ",&
"Arguments a and b not conformable                                       ",&
"Arguments a and c not conformable                                       ",&
"Arguments b and c not conformable                                       ",&
"Arguments x and q have different dimensions                             ",&
"Arguments x and y have incompatible dimensions                          ",&
"Attempted division by zero                                              ",&
"Attempted division by zero; procedure aborted                           ",&
"Attempted logarithm of non-positive number                              ",&
"Cannot estimate variance; fewer than 2 cases                            ",&
"Computation of loglikelihood aborted                                    ",&
"Could not initialize random seeds                                       ",&
"Cov. matrix became non-positive definite                                ",&
"Cov. matrix became singular or negative definite                        ",&
"Degrees of freedom not positive                                         ",&
"Dimensions of matrix arguments not conformable                          ",&
"Dimensions of x and y not conformable                                   ",&
"EM algorithm aborted                                                    ",&
"Eigen power method failed to converge                                   ",&
"Error: stack size is too small                                          ",&
"Failed to tabulate data                                                 ",&
"Fewer than two observed cases available                                 ",&
"Finite-differencing procedure strayed outside                           ",&
"First element of v is not 1.D0                                          ",&
"Imputation procedure aborted                                            ",&
"Incorrect dimensions for argument beta_start                            ",&
"Incorrect dimensions for argument sigma_start                           ",&
"Incorrect dimensions for array argument beta                            ",&
"Incorrect dimensions for array argument sigma                           ",&
"Incorrect size for argument worst_linear_coef                           ",&
"Input argument vec has length zero                                      ",&
"Length of vec(1) greater than max_string_length                         ",&
"Lower bound exceeds upper bound                                         ",&
"MCMC procedure aborted                                                  ",&
"Matrix apparently singular                                              ",&
"Matrix not positive definite                                            ",&
"Non-square matrix encountered; square expected                          ",&
"Operation failed                                                        ",&
"Output argument does not match table type                               ",&
"Parameters out of order                                                 ",&
"Pivot out of bounds                                                     ",&
"Posterior distribution may not be proper                                ",&
"Predictor (X) matrix does not have full rank                            ",&
"Prior type not recognized                                               ",&
"Prior_df cannot be negative for ridge prior                             ",&
"Random generator seeds have not been set                                ",&
"Shape or scale parameter not positive                                   ",&
"Table object is null                                                    ",&
"Unable to allocate memory for object                                    ",&
"Unable to deallocate memory for object                                  ",&
"Unable to regress response on x                                         ",&
"Workspace wkn has incorrect length                                      ",&
"Workspace wkp has incorrect length                                      ",&
"Workspace wkp1 or wkp2 has incorrect length                             ",&
"Zero variance; observed values are identical                            ",&
"parameter space; solution at or near boundary                           ",&
