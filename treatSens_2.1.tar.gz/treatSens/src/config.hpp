/* #define HAVE_CSTDINT 1 */
#define HAVE_GETTIMEOFDAY 1
#define HAVE_STDINT_H 1
#define HAVE_SYS_TIME_H 1
/* #define HAVE_ALLOCA_H 1 */
#define STDC_HEADERS 1

#define restrict __restrict

#define PACKAGE_BUGREPORT "vdorie@gmail.com"
#define PACKAGE_NAME "treatSens"
#define PACKAGE_STRING "treatSens 3.0"
#define PACKAGE_TARNAME "treatSens"
#define PACKAGE_VERSION "3.0"
